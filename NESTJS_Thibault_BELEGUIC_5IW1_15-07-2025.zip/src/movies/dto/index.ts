export * from './create-movie.dto';
export * from './update-movie.dto'; 